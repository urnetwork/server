module urnetwork.local/completed-qualification-retained-archive

go 1.27.3

require (
	github.com/ChainSafe/go-schnorrkel v1.1.0
	github.com/TwiN/go-away v1.8.0
	github.com/aws/aws-sdk-go v1.55.8
	github.com/btcsuite/btcutil v1.0.3-0.20201208143702-a53e38424cce
	github.com/centrifuge/go-substrate-rpc-client/v4 v4.2.2-0.20240919131012-e3b938563803
	github.com/cespare/xxhash/v2 v2.3.0
	github.com/coinbase/cdp-sdk/go v0.0.0-20261022213558-658e227219e3
	github.com/coreos/go-semver v0.3.1
	github.com/docopt/docopt-go v0.0.0-20180111231733-ee0de3bc6815
	github.com/ethereum/go-ethereum v1.17.0
	github.com/gagliardetto/solana-go v1.21.0
	github.com/go-jose/go-jose/v3 v3.0.5
	github.com/go-playground/assert/v2 v2.2.0
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/google/uuid v1.6.0
	github.com/gorilla/websocket v1.5.3
	github.com/holiman/uint256 v1.3.2
	github.com/jackc/pgerrcode v0.0.0-20250907135507-afb5586c32a6
	github.com/jackc/pgx/v5 v5.10.0
	github.com/klauspost/compress v1.19.2
	github.com/mailgun/proxyproto v1.0.0
	github.com/maxmind/mmdbwriter v1.1.0
	github.com/minio/minio-go/v7 v7.2.1
	github.com/modelcontextprotocol/go-sdk v1.7.0
	github.com/mozillazg/go-unidecode v0.2.0
	github.com/mr-tron/base58 v1.3.0
	github.com/multiformats/go-multiaddr v0.16.1
	github.com/nyaruka/phonenumbers v1.6.5
	github.com/oschwald/maxminddb-golang/v2 v2.4.1
	github.com/pion/logging v0.2.4
	github.com/pion/transport/v4 v4.1.0
	github.com/pquerna/cachecontrol v0.2.0
	github.com/prometheus/client_golang v1.24.1
	github.com/prometheus/client_model v0.6.2
	github.com/quic-go/quic-go v0.61.0
	github.com/redis/go-redis/v9 v9.23.0
	github.com/skip2/go-qrcode v0.0.0-20200617195104-da1b6568686e
	github.com/stripe/stripe-go/v82 v82.5.1
	github.com/tyler-smith/go-bip39 v1.1.0
	github.com/ulikunitz/xz v0.5.15
	github.com/urfoundation/sn v0.0.0
	github.com/urnetwork/connect v0.0.0
	github.com/urnetwork/glog v0.0.0
	github.com/urnetwork/proxy v0.0.0
	github.com/urnetwork/sdk v0.0.0
	github.com/urnetwork/userwireguard v0.0.0
	golang.org/x/crypto v0.58.0
	golang.org/x/mod v0.41.0
	golang.org/x/net v0.62.0
	golang.org/x/oauth2 v0.36.0
	golang.org/x/sys v0.49.0
	golang.org/x/text v0.43.0
	golang.zx2c4.com/wireguard/wgctrl v0.0.0-20241231184526-a9ab2273dd10
	google.golang.org/protobuf v1.36.11
	gopkg.in/yaml.v3 v3.0.1
	gvisor.dev/gvisor v0.0.0-20260909230408-9b1144b679cb
)

require (
	github.com/Microsoft/go-winio v0.6.2 // indirect
	github.com/ProjectZKM/Ziren/crates/go-runtime/zkvm_runtime v0.0.0-20251001021608-1fe7b43fc4d6 // indirect
	github.com/StackExchange/wmi v1.2.1 // indirect
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/benbjohnson/clock v1.3.5 // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/bits-and-blooms/bitset v1.24.4 // indirect
	github.com/blendle/zapdriver v1.3.1 // indirect
	github.com/consensys/gnark-crypto v0.20.1 // indirect
	github.com/cosmos/go-bip39 v1.0.0 // indirect
	github.com/crate-crypto/go-eth-kzg v1.4.0 // indirect
	github.com/davecgh/go-spew v1.1.2-0.20180830191138-d8f796af33cc // indirect
	github.com/davidlazar/go-crypto v0.0.0-20200604182044-b73af7476f6c // indirect
	github.com/deckarep/golang-set v1.8.0 // indirect
	github.com/deckarep/golang-set/v2 v2.6.0 // indirect
	github.com/decred/base58 v1.0.4 // indirect
	github.com/decred/dcrd/crypto/blake256 v1.1.0 // indirect
	github.com/decred/dcrd/dcrec/secp256k1/v4 v4.4.1 // indirect
	github.com/dustin/go-humanize v1.0.1 // indirect
	github.com/emicklei/dot v1.6.2 // indirect
	github.com/ethereum/c-kzg-4844/v2 v2.1.5 // indirect
	github.com/fatih/color v1.19.0 // indirect
	github.com/ferranbt/fastssz v0.1.4 // indirect
	github.com/filecoin-project/go-clock v0.1.0 // indirect
	github.com/flynn/noise v1.1.0 // indirect
	github.com/fsnotify/fsnotify v1.9.0 // indirect
	github.com/gagliardetto/binary v0.8.0 // indirect
	github.com/gagliardetto/treeout v0.1.4 // indirect
	github.com/go-logr/logr v1.4.3 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/go-ole/go-ole v1.3.0 // indirect
	github.com/goccy/go-json v0.10.6 // indirect
	github.com/gofrs/flock v0.13.0 // indirect
	github.com/golang/snappy v1.0.0 // indirect
	github.com/google/btree v1.1.3 // indirect
	github.com/google/jsonschema-go v0.4.3 // indirect
	github.com/gtank/merlin v0.1.1 // indirect
	github.com/gtank/ristretto255 v0.1.2 // indirect
	github.com/hashicorp/golang-lru/v2 v2.0.7 // indirect
	github.com/huin/goupnp v1.3.0 // indirect
	github.com/ipfs/go-cid v0.6.2 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	github.com/jackpal/go-nat-pmp v1.0.2 // indirect
	github.com/jbenet/go-temp-err-catcher v0.1.0 // indirect
	github.com/jmespath/go-jmespath v0.4.0 // indirect
	github.com/klauspost/cpuid/v2 v2.4.0 // indirect
	github.com/klauspost/crc32 v1.3.0 // indirect
	github.com/koron/go-ssdp v0.9.1 // indirect
	github.com/kylelemons/godebug v1.1.0 // indirect
	github.com/libp2p/go-buffer-pool v0.1.0 // indirect
	github.com/libp2p/go-flow-metrics v0.3.0 // indirect
	github.com/libp2p/go-libp2p v0.49.0 // indirect
	github.com/libp2p/go-libp2p-asn-util v0.4.1 // indirect
	github.com/libp2p/go-libp2p-pubsub v0.17.0 // indirect
	github.com/libp2p/go-msgio v0.3.0 // indirect
	github.com/libp2p/go-netroute v0.4.0 // indirect
	github.com/libp2p/go-reuseport v0.4.0 // indirect
	github.com/libp2p/go-yamux/v5 v5.1.0 // indirect
	github.com/logrusorgru/aurora v2.0.3+incompatible // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mimoo/StrobeGo v0.0.0-20220103164710-9a04d6ca976b // indirect
	github.com/minio/crc64nvme v1.1.1 // indirect
	github.com/minio/md5-simd v1.1.2 // indirect
	github.com/minio/sha256-simd v1.0.1 // indirect
	github.com/mitchellh/go-testing-interface v1.14.1 // indirect
	github.com/mitchellh/mapstructure v1.5.0 // indirect
	github.com/mostynb/zstdpool-freelist v0.0.0-20201229113212-927304c0c3b1 // indirect
	github.com/multiformats/go-base32 v0.1.0 // indirect
	github.com/multiformats/go-base36 v0.2.0 // indirect
	github.com/multiformats/go-multiaddr-dns v0.6.0 // indirect
	github.com/multiformats/go-multiaddr-fmt v0.1.0 // indirect
	github.com/multiformats/go-multibase v0.3.0 // indirect
	github.com/multiformats/go-multicodec v0.10.0 // indirect
	github.com/multiformats/go-multihash v0.2.3 // indirect
	github.com/multiformats/go-multistream v0.6.1 // indirect
	github.com/multiformats/go-varint v0.1.0 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/oasisprotocol/curve25519-voi v0.0.0-20251114093237-2ab5a27a1729 // indirect
	github.com/philhofer/fwd v1.2.0 // indirect
	github.com/pierrec/xxHash v0.1.5 // indirect
	github.com/pion/datachannel v1.6.2 // indirect
	github.com/pion/dtls/v3 v3.1.5 // indirect
	github.com/pion/ice/v4 v4.4.1 // indirect
	github.com/pion/interceptor v0.1.47 // indirect
	github.com/pion/mdns/v2 v2.1.0 // indirect
	github.com/pion/randutil v0.1.0 // indirect
	github.com/pion/rtcp v1.2.17 // indirect
	github.com/pion/rtp v1.10.5 // indirect
	github.com/pion/sctp v1.11.1 // indirect
	github.com/pion/sdp/v3 v3.0.19 // indirect
	github.com/pion/srtp/v3 v3.0.13 // indirect
	github.com/pion/stun/v3 v3.1.6 // indirect
	github.com/pion/turn/v5 v5.0.12 // indirect
	github.com/pion/webrtc/v4 v4.2.18 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/prometheus/common v0.70.1 // indirect
	github.com/prometheus/procfs v0.21.1 // indirect
	github.com/quic-go/qpack v0.6.0 // indirect
	github.com/quic-go/webtransport-go v0.12.0 // indirect
	github.com/refraction-networking/utls v1.8.2 // indirect
	github.com/rivo/uniseg v0.4.7 // indirect
	github.com/rs/cors v1.8.2 // indirect
	github.com/rs/xid v1.6.0 // indirect
	github.com/segmentio/asm v1.1.3 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/shirou/gopsutil v3.21.4-0.20210419000835-c7a38de76ee5+incompatible // indirect
	github.com/spaolacci/murmur3 v1.1.0 // indirect
	github.com/streamingfast/logging v0.0.0-20250404134358-92b15d2fbd2e // indirect
	github.com/stretchr/objx v0.5.3 // indirect
	github.com/stretchr/testify v1.12.1 // indirect
	github.com/supranational/blst v0.3.16-0.20250831170142-f48500c1fdbe // indirect
	github.com/syndtr/goleveldb v1.0.1-0.20210819022825-2ae1ddf74ef7 // indirect
	github.com/theodorsm/covert-dtls v1.5.1 // indirect
	github.com/tinylib/msgp v1.6.4 // indirect
	github.com/tklauser/go-sysconf v0.3.12 // indirect
	github.com/tklauser/numcpus v0.6.1 // indirect
	github.com/urnetwork/goidenticons v0.0.0 // indirect
	github.com/vedhavyas/go-subkey/v2 v2.0.0 // indirect
	github.com/wlynxg/anet v0.0.5 // indirect
	github.com/yosida95/uritemplate/v3 v3.0.2 // indirect
	github.com/zeebo/xxh3 v1.1.0 // indirect
	go.mongodb.org/mongo-driver/v2 v2.5.0 // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.opentelemetry.io/otel v1.43.0 // indirect
	go.opentelemetry.io/otel/metric v1.43.0 // indirect
	go.opentelemetry.io/otel/trace v1.43.0 // indirect
	go.uber.org/atomic v1.12.0 // indirect
	go.uber.org/multierr v1.11.0 // indirect
	go.uber.org/zap v1.28.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	go4.org/netipx v0.0.0-20231129151722-fdeea329fbba // indirect
	golang.org/x/exp v0.0.0-20260727155853-b88d891fe743 // indirect
	golang.org/x/image v0.44.0 // indirect
	golang.org/x/sync v0.24.0 // indirect
	golang.org/x/term v0.47.0 // indirect
	golang.org/x/time v0.15.0 // indirect
	gopkg.in/ini.v1 v1.67.3 // indirect
	gopkg.in/natefinch/npipe.v2 v2.0.0-20160621034901-c1b8fa8bdcce // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
	lukechampine.com/blake3 v1.4.1 // indirect
	src.agwa.name/tlshacks v0.0.4 // indirect
)

// Use the same sibling sources in local builds and frozen PERF arms.
// Replacements in imported modules are not inherited by Go.
replace github.com/urnetwork/connect => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/connect

replace github.com/pion/sctp => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/connect/sctp

replace github.com/urnetwork/proxy => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/proxy

replace github.com/urnetwork/sdk => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/sdk

replace github.com/urnetwork/glog => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/glog

replace github.com/urnetwork/goidenticons => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/goidenticons

replace github.com/urnetwork/userwireguard => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/userwireguard

replace github.com/urfoundation/sn => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/sn

// Dependency replacements are not inherited from SN; share its corrected
// native RPC transport and tracked upstream provenance in server binaries.
replace github.com/centrifuge/go-substrate-rpc-client/v4 => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/sn/third_party/go-substrate-rpc-client

// Share the fork's source with local builds and frozen PERF arms. The source
// lock (local/source-graph/lock.yml) pins this sibling's full revision; the
// release builder converts it to an immutable pin.
replace gvisor.dev/gvisor => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/gvisor

require github.com/urnetwork/server v0.0.0

replace github.com/urnetwork/server => /mnt/data/urnetwork-competition-temp/competition-intake-fixed-low-20261028.NVLnwGLW/source/server
