// The completed-evidence adapter changes only a closed compiled identity; these
// controls inspect defaults or refuse unknown roots before touching a source.
package main

import (
	"strings"
	"testing"
	"time"
)

// Pins the reviewed manifest, one exact source unit, and unchanged compliance
// deadline without interpreting any qualification result or archive content.
func TestCompletedEvidencePolicyPinsCuratedIdentity(t *testing.T) {
	policy := defaultArchivePolicy()
	source := "/var/lib/urnetwork/competition-qg-h1-completed-custody-20261029-v1/source"
	if policy.OwnerUid != 0 || policy.Anchor != "/" || policy.WorkParent != "/var/lib/urnetwork" || policy.Owner == "" ||
		policy.Context != "completed-genuine-qg6-h1-worse112x3-20261029-v1" ||
		policy.PublicPlanSha256 != "343636340f65dfa3886eae64c5dbf5f3edeba8099b3f334a3c8355145eeddf68" ||
		policy.WorkPrefix != "competition-completed-qualification-retained-archive-" ||
		policy.KeyPrefix != "blob/competition/qualification/completed-qg6-h1-worse112x3-20261029-v1" ||
		policy.Bucket != "competition" || !policy.RetainUntil.Equal(time.Date(2028, 1, 1, 0, 0, 0, 0, time.UTC)) ||
		len(policy.SourceRootUnits) != 1 || policy.SourceRootUnits[source] != "qg6-and-h1-worse112x3" {
		t.Fatal("compiled adapter changed its exact reviewed custody identity")
	}
	if archivePlanKind != "retained-archive-plan" || archiveInventoryKind != "retained-archive-inventory" ||
		strings.Contains(policy.Context, "first-committed") {
		t.Fatal("completed evidence was mislabeled as an earlier seed campaign")
	}
}

// No caller-controlled source, old-context path, child, ancestor, or lexical
// alias is admitted; absent map entries are refused before any filesystem read.
func TestCompletedEvidencePolicyRejectsOtherRootsAndAliases(t *testing.T) {
	policy := defaultArchivePolicy()
	source := "/var/lib/urnetwork/competition-qg-h1-completed-custody-20261029-v1/source"
	for _, root := range []string{
		"/synthetic-unrelated-campaign",
		"/var/lib/urnetwork",
		strings.TrimSuffix(source, "/source"),
		source + "/child",
		source + "/.",
		source + "/../source",
	} {
		if _, exists := policy.SourceRootUnits[root]; exists {
			t.Fatalf("unexpected compiled source root %q", root)
		}
		if _, err := sourceUnit(root, policy); err == nil {
			t.Fatalf("unlisted or aliased source root admitted: %q", root)
		}
	}
}
